
/* Copyright (c) Mark J. Kilgard, 1994, 1996. */

/* This program is freely distributable without licensing fees and
   is provided without guarantee or warrantee expressed or implied.
   This program is -not- in the public domain. */
   
#include <glutint.h>

void *glut_bitmap_times_roman_10_ = &glutBitmapTimesRoman10;

