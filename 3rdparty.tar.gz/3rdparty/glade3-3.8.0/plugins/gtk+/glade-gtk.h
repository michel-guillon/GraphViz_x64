/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef __GLADE_GTK_H__
#define __GLADE_GTK_H__

#include <gladeui/glade.h>
#include <gtk/gtk.h>


/* Types */

GParamSpec *glade_gtk_gnome_ui_info_spec   (void);

			 		    
#endif /* __GLADE_GTK_H__ */
