/* config-h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the `argz_add' function. */
#undef HAVE_ARGZ_ADD

/* Define to 1 if you have the `argz_append' function. */
#undef HAVE_ARGZ_APPEND

/* Define to 1 if you have the `argz_count' function. */
#undef HAVE_ARGZ_COUNT

/* Define to 1 if you have the `argz_create_sep' function. */
#undef HAVE_ARGZ_CREATE_SEP

/* Define to 1 if you have the <argz.h> header file. */
#undef HAVE_ARGZ_H

/* Define to 1 if you have the `argz_insert' function. */
#undef HAVE_ARGZ_INSERT

/* Define to 1 if you have the `argz_next' function. */
#undef HAVE_ARGZ_NEXT

/* Define to 1 if you have the `argz_stringify' function. */
#undef HAVE_ARGZ_STRINGIFY

/* Define to 1 if you have the `closedir' function. */
#undef HAVE_CLOSEDIR

/* Define to 1 if you have the declaration of `cygwin_conv_path', and to 0 if
   you don't. */
#undef HAVE_DECL_CYGWIN_CONV_PATH

/* Define to 1 if you have the <dirent.h> header file. */
#undef HAVE_DIRENT_H

/* Define if you have the GNU dld library. */
#undef HAVE_DLD

/* Define to 1 if you have the <dld.h> header file. */
#undef HAVE_DLD_H

/* Define to 1 if you have the `dlerror' function. */
#undef HAVE_DLERROR

/* Define to 1 if you have the <dlfcn.h> header file. */
#undef HAVE_DLFCN_H

/* Define to 1 if you have the <dl.h> header file. */
#undef HAVE_DL_H

/* Define if you have the _dyld_func_lookup function. */
#undef HAVE_DYLD

/* Define to 1 if the system has the type `error_t'. */
#undef HAVE_ERROR_T

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define if you have the libdl library or equivalent. */
#undef HAVE_LIBDL

/* Define if libdlloader will be built on this platform */
#undef HAVE_LIBDLLOADER

/* Define to 1 if you have the <mach-o/dyld.h> header file. */
#undef HAVE_MACH_O_DYLD_H

/* Define to 1 if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define to 1 if you have the `opendir' function. */
#undef HAVE_OPENDIR

/* Define if libtool can extract symbol lists from object files. */
#undef HAVE_PRELOADED_SYMBOLS

/* Define to 1 if you have the `readdir' function. */
#undef HAVE_READDIR

/* Define if you have the shl_load function. */
#undef HAVE_SHL_LOAD

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define to 1 if you have the `strlcat' function. */
#undef HAVE_STRLCAT

/* Define to 1 if you have the `strlcpy' function. */
#undef HAVE_STRLCPY

/* Define to 1 if you have the <sys/dl.h> header file. */
#undef HAVE_SYS_DL_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* This value is set to 1 to indicate that the system argz facility works */
#undef HAVE_WORKING_ARGZ

/* Define if the OS needs help to load dependent libraries for dlopen(). */
#undef LTDL_DLOPEN_DEPLIBS

/* Define to the system default library search path. */
#undef LT_DLSEARCH_PATH

/* The archive extension */
#undef LT_LIBEXT

/* The archive prefix */
#undef LT_LIBPREFIX

/* Define to the extension used for runtime loadable modules, say, ".so". */
#undef LT_MODULE_EXT

/* Define to the name of the environment variable that determines the run-time
   module search path. */
#undef LT_MODULE_PATH_VAR

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#undef LT_OBJDIR

/* Define to the shared library suffix, say, ".dylib". */
#undef LT_SHARED_EXT

/* Define if dlsym() requires a leading underscore in symbol names. */
#undef NEED_USCORE

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the home page for this package. */
#undef PACKAGE_URL

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Version number of package */
#undef VERSION

/* Define so that glibc/gnulib argp.h does not typedef error_t. */
#undef __error_t_defined

/* Define to a type to use for `error_t' if it is not otherwise available. */
//#undef error_t
typedef int error_t;